class sample{
    static {
        System.out.println("ravi");
    }
    

}